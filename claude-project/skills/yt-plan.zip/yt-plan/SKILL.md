---
name: yt-plan
description: >-
  Plan a week or a month of YouTube uploads - what to post, when, and in
  what order, sized to the creator's actual capacity. Use for "plan my
  week", "content calendar", "what should I post", "I have no idea what to
  make next".
---

# yt-plan

A plan that does not fit the week is a list of regrets. Ask two questions before writing anything:
**how many hours do you actually have**, and **what is already half-made**.

## Before you write

1. Read `.claude/youtube/voice.md` in the current project, else `~/.claude/youtube/voice.md`, else this skill's template at `channel/voice.md` from this skill's folder. That is the user's voice profile: how they talk
   on camera, the words they never use, who they are talking to, what they will not claim. If it
   does not exist, ask for **three of their own videos**, read or transcribe them, infer the voice,
   and write the file. A script in the wrong voice is worse than no script, because they have to
   read it out loud.
2. Never invent a number, a result or a source. If a figure would strengthen it and you do not have
   one, ask for it or write the line without it.

## The shape of a week

- **One anchor.** The video the week is for. It gets the most time and it goes out on the day the
  channel's own analytics say is best - ask for that, do not assume Tuesday.
- **One cheap one.** Built from something that exists: a clip, a reaction, a follow-up to the
  comment that got the most replies last week.
- **Shorts from the anchor.** Three, cut from the long video, not written separately. `/yt-shorts`
  finds them.

Three uploads on a seven-day week, not seven. A plan that posts daily is not a plan anyone
recognises, and the empty days are what make the filled ones survive a bad week.

## What to hand back

A table: day, format, working title, the one sentence it promises, and what already exists for it.
Then the honest line at the bottom - how many hours this costs, and what to drop first if the week
goes wrong.

## The niche

This channel is a Persian-language channel about **ruqyah shar'iyyah** (رقیه شرعیه). Before writing,
read `.claude/youtube/niche.md` in the current project (or `channel/niche.md` from this skill's folder, this skill's copy). Write every output in Persian. The red lines in that
file are hard limits: no promised or guaranteed cures, nothing that presents ruqyah as a replacement
for a doctor, no diagnosing anyone remotely, no fear-based packaging, and no Quranic text or hadith
written from memory. Leave a marked placeholder for the user to paste the verified text instead.
If a request crosses one of these lines, say which one and offer the version that stays inside it.

## The gate

Nothing here publishes. This skill writes and you publish. Every output ends in a block the user
copies, and the last line of every run is the question: **ship it, or change it?**
